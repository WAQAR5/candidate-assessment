import React from "react";
import RegistrationForm from "../component/Registration/registration";
const Registration = () => {
  return (
    <>
      <RegistrationForm />
    </>
  );
};

export default Registration;
