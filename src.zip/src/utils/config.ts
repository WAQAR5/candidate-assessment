const mainnetConfig = {
  RPC_URL: "https://polygon-rpc.com/ ",
  CONTRACT_ADDRESS: "0x8741e37746ec135F00dEfe30a81770C2c52d2135",
};

const testnetConfig = {
  RPC_URL: "https://rpc-mumbai.maticvigil.com/",
  CONTRACT_ADDRESS: "0x8741e37746ec135F00dEfe30a81770C2c52d2135",
};

export default testnetConfig;
